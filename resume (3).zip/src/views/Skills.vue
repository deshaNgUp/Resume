<template>
    <div>
        <LevelBar level="4" />
    </div>
</template>

<script>
    import LevelBar from "../components/LevelBar";

    export default {
        name      : 'Skills',
        components: {
            LevelBar
        }
    }
</script>
