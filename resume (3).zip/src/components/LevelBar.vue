<template>
    <div class="level-bar">
        <div v-for="index in limit" :key="index" v-bind:class="{ active: index <= counter }" class="level-bar-item"></div>
    </div>
</template>

<script>
    export default {
        name : 'LevelBar',
        props: ['level', 'max'],
        data : function () {
            return {
                counter: this.level || 0,
                limit  : this.max || 10
            }
        }
    }
</script>

<style scoped lang="scss">
    @import "../assets/scss/variables";

    .level-bar {
        display: inline-flex;
    }

    .level-bar-item {
        width: 20px;
        height: 20px;

        border-radius: 5px;
        border: 2px solid #fff;
        box-shadow: 2px 2px 4px 1px rgba(0, 0, 0, 0.5), inset 2px 2px 5px 0 rgba(0, 0, 0, 0.5);

        &.active {
            background: $gradient;
        }

        & + & {
            margin-left: 10px;
        }
    }
</style>
