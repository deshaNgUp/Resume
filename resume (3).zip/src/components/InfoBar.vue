<template>
	<div class="info-bar">
		<h1 class="mr-bottom-gap">Contact information</h1>
	</div>
</template>

<script>
export default {
  name: 'InfoBar',
}
</script>

<style scoped lang="scss">
	.info-bar {

	}
</style>
