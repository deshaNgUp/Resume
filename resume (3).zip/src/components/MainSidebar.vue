<template>
	<div class="main-sidebar">
		<h1 class="text-center mr-bottom-gap">Some words about me</h1>
		<div class="photo-wrapper">
			<img src="@/assets/img/photo.jpg" class="photo shadow mr-auto" />
		</div>
        <ol class="list own-counter">
            <li class="own-counter-item">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Accusamus corporis dicta dolor ea enim iure magni placeat sunt voluptatum?
            </li>
            <li class="own-counter-item">
                Accusantium aliquid atque dicta, eligendi eveniet in quasi quidem repudiandae voluptatibus
            </li>
            <li class="own-counter-item">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                A asperiores, facere harum, incidunt libero minima nemo,
                officia quos temporibus totam ullam velit.
            </li>
            <li class="own-counter-item">
                Lorem ipsum dolor sit amet. Consequuntur corporis laborum neque. Doloremque hic quis sed?
            </li>
        </ol>
	</div>
</template>

<script>
export default {
  name: 'MainSidebar',
}
</script>

<style scoped lang="scss">
    @import '../assets/scss/variables';

	.list {
        max-width: 500px;
        text-align: justify;

        padding: 0;
        margin: 20px auto;
	}

	.photo-wrapper {
        padding: 15px 15px 35px;
	}

	.photo {
		max-width: 80%;
		object-fit: cover;
	}

    .own-counter {
        list-style: none;
    }

    .own-counter-item {
        display: flex;
        counter-increment: list;
        position: relative;

        & + & {
            margin-top: 25px;
        }

        &:before {
            content: counter(list);
            background: $gradient;
            border-radius: 0 50% 50% 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;

            flex-shrink: 0;
            width: 40px;
            height: 40px;

            z-index: 1;
            color: #fff;
        }

        &:after {
            width: 2.5rem;
            height: 2.5rem;
            position: absolute;
            top: 0;
            left: 0;
            content: "";
            background: var(--highlight1);
            z-index: -1;
            border-top-left-radius: 3px;
        }
    }
</style>
